def process_user_input(message):
    # Dummy response based on keywords
    if "book" in message.lower():
        return "✅ Booking confirmed for tomorrow at 4 PM!"
    else:
        return "👋 Hi! I can help you book meetings. Try saying 'Book a call tomorrow at 4 PM'."
