from fastapi import FastAPI, Request
from backend.calendar_utils import create_event
from backend.langchain_agent import process_user_input

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "TailorTalk API is running"}

@app.post("/chat")
async def chat(request: Request):
    data = await request.json()
    user_message = data.get("message")

    # Pass the message to the LangChain agent (dummy logic for now)
    response = process_user_input(user_message)
    return {"response": response}
