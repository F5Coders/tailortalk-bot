import streamlit as st
import requests

st.title("🧠 TailorTalk - AI Appointment Bot")
st.subheader("Chat with the bot to book meetings")

user_input = st.text_input("You: ")

if user_input:
    response = requests.post("http://localhost:8000/chat", json={"message": user_input})
    bot_reply = response.json()["response"]
    st.write(f"🤖 Bot: {bot_reply}")
